import React from 'react';
import weatherData from './weather_api_output.json';

const WeatherApp = () => {
  return (
    <div className="weather-app">
      <h1>Weather App</h1>
      <div className="weather-details">
        <h2>{weatherData.name}, {weatherData.sys.country}</h2>
        <p>Temperatura: {(weatherData.main.temp - 273.15).toFixed(2)}°C</p> {/* Convertir Kelvin a Celsius */}
        <p>Sensación térmica: {(weatherData.main.feels_like - 273.15).toFixed(2)}°C</p>
        <p>Condición: {weatherData.weather[0].description}</p>
        <p>Humedad: {weatherData.main.humidity}%</p>
        <img
          src={`http://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`}
          alt={weatherData.weather[0].description}
        />
      </div>
    </div>
  );
};

export default WeatherApp;
