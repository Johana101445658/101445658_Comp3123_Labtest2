import React from 'react'

export default function About() {
  return (
    <div>
        <h2>About Me</h2>
        <p>Lizette Johana Romero Estupinan</p>
        <p>Student id: 101445658</p>
        <p>George Brown College</p>
        
    </div>
  )
}