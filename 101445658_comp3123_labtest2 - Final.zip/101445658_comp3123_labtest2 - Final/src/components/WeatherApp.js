{weatherData && (
    <div className="weather-details">
      <h2>{weatherData.name}, {weatherData.sys.country}</h2>
      <p>Temperatura: {weatherData.main.temp}°C</p> {/* Muestra la temperatura */}
      <p>Sensación térmica: {weatherData.main.feels_like}°C</p> {/* Sensación térmica */}
      <p>Condición: {weatherData.weather[0].description}</p> {/* Descripción del clima */}
      <img
        src={`http://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`}
        alt={weatherData.weather[0].description}
      />
    </div>
  )}
  